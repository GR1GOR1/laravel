<?php if($label): ?>
    <span <?php echo $attributes->merge(['class' => 'text-gray-700']); ?>><?php echo e($label); ?></span>
<?php endif; ?><?php /**PATH D:\OSPanel\domains\example-app\vendor\protonemedia\laravel-form-components\src\Support/../../resources/views/tailwind/form-label.blade.php ENDPATH**/ ?>