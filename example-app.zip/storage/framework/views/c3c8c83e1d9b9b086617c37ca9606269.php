<?php if($type === 'hidden'): ?> <div class="d-none"> <?php endif; ?>
<?php if($floating): ?> <div class="form-floating"> <?php endif; ?>

    <?php if(!$floating): ?>
        <?php if (isset($component)) { $__componentOriginalfbbe8b6ca40abf152d2eb23603f97612 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalfbbe8b6ca40abf152d2eb23603f97612 = $attributes; } ?>
<?php $component = ProtoneMedia\LaravelFormComponents\Components\FormLabel::resolve(['label' => $label] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('form-label'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(ProtoneMedia\LaravelFormComponents\Components\FormLabel::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['for' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($attributes->get('id') ?: $id())]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalfbbe8b6ca40abf152d2eb23603f97612)): ?>
<?php $attributes = $__attributesOriginalfbbe8b6ca40abf152d2eb23603f97612; ?>
<?php unset($__attributesOriginalfbbe8b6ca40abf152d2eb23603f97612); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalfbbe8b6ca40abf152d2eb23603f97612)): ?>
<?php $component = $__componentOriginalfbbe8b6ca40abf152d2eb23603f97612; ?>
<?php unset($__componentOriginalfbbe8b6ca40abf152d2eb23603f97612); ?>
<?php endif; ?>
    <?php endif; ?>

    <input
        <?php echo $attributes->merge(['class' => 'form-control' . ($type === 'color' ? ' form-control-color' : '') . ($hasError($name) ? ' is-invalid' : '')]); ?>


        type="<?php echo e($type); ?>"

        <?php if($isWired()): ?>
            wire:model<?php echo $wireModifier(); ?>="<?php echo e($name); ?>"
        <?php else: ?>
            value="<?php echo e($value ?? ($type === 'color' ? '#000000' : '')); ?>"
        <?php endif; ?>

        name="<?php echo e($name); ?>"

        <?php if($label && !$attributes->get('id')): ?>
            id="<?php echo e($id()); ?>"
        <?php endif; ?>

        
        <?php if($floating && !$attributes->get('placeholder')): ?>
            placeholder="&nbsp;"
        <?php endif; ?>
    />

    <?php if($floating): ?>
        <?php if (isset($component)) { $__componentOriginalfbbe8b6ca40abf152d2eb23603f97612 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalfbbe8b6ca40abf152d2eb23603f97612 = $attributes; } ?>
<?php $component = ProtoneMedia\LaravelFormComponents\Components\FormLabel::resolve(['label' => $label] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('form-label'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(ProtoneMedia\LaravelFormComponents\Components\FormLabel::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['for' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($attributes->get('id') ?: $id())]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalfbbe8b6ca40abf152d2eb23603f97612)): ?>
<?php $attributes = $__attributesOriginalfbbe8b6ca40abf152d2eb23603f97612; ?>
<?php unset($__attributesOriginalfbbe8b6ca40abf152d2eb23603f97612); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalfbbe8b6ca40abf152d2eb23603f97612)): ?>
<?php $component = $__componentOriginalfbbe8b6ca40abf152d2eb23603f97612; ?>
<?php unset($__componentOriginalfbbe8b6ca40abf152d2eb23603f97612); ?>
<?php endif; ?>
    <?php endif; ?>

<?php if($floating): ?> </div> <?php endif; ?>

<?php echo $help ?? null; ?>


<?php if($hasErrorAndShow($name)): ?>
    <?php if (isset($component)) { $__componentOriginal05e9bdd21fe5d6ded727203914658ba5 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal05e9bdd21fe5d6ded727203914658ba5 = $attributes; } ?>
<?php $component = ProtoneMedia\LaravelFormComponents\Components\FormErrors::resolve(['name' => $name] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('form-errors'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(ProtoneMedia\LaravelFormComponents\Components\FormErrors::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal05e9bdd21fe5d6ded727203914658ba5)): ?>
<?php $attributes = $__attributesOriginal05e9bdd21fe5d6ded727203914658ba5; ?>
<?php unset($__attributesOriginal05e9bdd21fe5d6ded727203914658ba5); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal05e9bdd21fe5d6ded727203914658ba5)): ?>
<?php $component = $__componentOriginal05e9bdd21fe5d6ded727203914658ba5; ?>
<?php unset($__componentOriginal05e9bdd21fe5d6ded727203914658ba5); ?>
<?php endif; ?>
<?php endif; ?>

<?php if($type === 'hidden'): ?> </div> <?php endif; ?>
<?php /**PATH D:\OSPanel\domains\example-app\vendor\protonemedia\laravel-form-components\src\Support/../../resources/views/bootstrap-5/form-input.blade.php ENDPATH**/ ?>