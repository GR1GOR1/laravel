<?php if (isset($component)) { $__componentOriginal11b7562b3a376be9cd97a7ea033a3218 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal11b7562b3a376be9cd97a7ea033a3218 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layout.main','data' => ['title' => 'Trashed cars','h1' => 'Cars']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('layout.main'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Trashed cars','h1' => 'Cars']); ?>
    <hr>
    <a href="<?php echo e(route('cars.index')); ?>">Список всех машин</a>
    <hr>
    <div class="roe">
        <?php $__currentLoopData = $cars; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $car): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col m-3">
                <h3><?php echo e($car->model); ?> / <?php echo e($car->brand); ?></h3>
                <?php if (isset($component)) { $__componentOriginal38da2dbee375aea5e7cbb453375a9e32 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal38da2dbee375aea5e7cbb453375a9e32 = $attributes; } ?>
<?php $component = ProtoneMedia\LaravelFormComponents\Components\Form::resolve(['method' => 'put'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('form'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(ProtoneMedia\LaravelFormComponents\Components\Form::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['action' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(route('cars.restore', [ $car->id ]))]); ?>
                    <button class="btn btn-success">Восстановить</button>
                 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal38da2dbee375aea5e7cbb453375a9e32)): ?>
<?php $attributes = $__attributesOriginal38da2dbee375aea5e7cbb453375a9e32; ?>
<?php unset($__attributesOriginal38da2dbee375aea5e7cbb453375a9e32); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal38da2dbee375aea5e7cbb453375a9e32)): ?>
<?php $component = $__componentOriginal38da2dbee375aea5e7cbb453375a9e32; ?>
<?php unset($__componentOriginal38da2dbee375aea5e7cbb453375a9e32); ?>
<?php endif; ?>
                <!-- <a href="<?php echo e(route('cars.edit', [$car->id])); ?>">Восстановить</a> -->
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal11b7562b3a376be9cd97a7ea033a3218)): ?>
<?php $attributes = $__attributesOriginal11b7562b3a376be9cd97a7ea033a3218; ?>
<?php unset($__attributesOriginal11b7562b3a376be9cd97a7ea033a3218); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal11b7562b3a376be9cd97a7ea033a3218)): ?>
<?php $component = $__componentOriginal11b7562b3a376be9cd97a7ea033a3218; ?>
<?php unset($__componentOriginal11b7562b3a376be9cd97a7ea033a3218); ?>
<?php endif; ?><?php /**PATH D:\OSPanel\domains\example-app\resources\views/cars/trashed.blade.php ENDPATH**/ ?>