<?php if (isset($component)) { $__componentOriginal11b7562b3a376be9cd97a7ea033a3218 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal11b7562b3a376be9cd97a7ea033a3218 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layout.main','data' => ['title' => 'Post '.e($post->title).'','h1' => ''.e($post->title).'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('layout.main'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Post '.e($post->title).'','h1' => ''.e($post->title).'']); ?>
    <div>
        <?php echo e($post->content); ?>

    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal11b7562b3a376be9cd97a7ea033a3218)): ?>
<?php $attributes = $__attributesOriginal11b7562b3a376be9cd97a7ea033a3218; ?>
<?php unset($__attributesOriginal11b7562b3a376be9cd97a7ea033a3218); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal11b7562b3a376be9cd97a7ea033a3218)): ?>
<?php $component = $__componentOriginal11b7562b3a376be9cd97a7ea033a3218; ?>
<?php unset($__componentOriginal11b7562b3a376be9cd97a7ea033a3218); ?>
<?php endif; ?><?php /**PATH D:\OSPanel\domains\example-app\resources\views/posts/show.blade.php ENDPATH**/ ?>