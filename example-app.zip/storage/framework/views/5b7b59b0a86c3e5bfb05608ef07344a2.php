<?php if (isset($component)) { $__componentOriginal11b7562b3a376be9cd97a7ea033a3218 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal11b7562b3a376be9cd97a7ea033a3218 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layout.main','data' => ['title' => 'Edit brand #'.e($brand->id).'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('layout.main'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Edit brand #'.e($brand->id).'']); ?>
    <?php if (isset($component)) { $__componentOriginal38da2dbee375aea5e7cbb453375a9e32 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal38da2dbee375aea5e7cbb453375a9e32 = $attributes; } ?>
<?php $component = ProtoneMedia\LaravelFormComponents\Components\Form::resolve(['method' => 'put'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('form'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(ProtoneMedia\LaravelFormComponents\Components\Form::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['action' => ''.e(route('brands.update', [ $brand->id ] )).'']); ?>
        <?php app(\ProtoneMedia\LaravelFormComponents\FormDataBinder::class)->bind($brand); ?>
            <?php echo $__env->make("brands.form", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php app(\ProtoneMedia\LaravelFormComponents\FormDataBinder::class)->pop(); ?>
        <div class="mb-3">
            <button class="btn btn-success">Сохранить</button>
        </div>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal38da2dbee375aea5e7cbb453375a9e32)): ?>
<?php $attributes = $__attributesOriginal38da2dbee375aea5e7cbb453375a9e32; ?>
<?php unset($__attributesOriginal38da2dbee375aea5e7cbb453375a9e32); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal38da2dbee375aea5e7cbb453375a9e32)): ?>
<?php $component = $__componentOriginal38da2dbee375aea5e7cbb453375a9e32; ?>
<?php unset($__componentOriginal38da2dbee375aea5e7cbb453375a9e32); ?>
<?php endif; ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal11b7562b3a376be9cd97a7ea033a3218)): ?>
<?php $attributes = $__attributesOriginal11b7562b3a376be9cd97a7ea033a3218; ?>
<?php unset($__attributesOriginal11b7562b3a376be9cd97a7ea033a3218); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal11b7562b3a376be9cd97a7ea033a3218)): ?>
<?php $component = $__componentOriginal11b7562b3a376be9cd97a7ea033a3218; ?>
<?php unset($__componentOriginal11b7562b3a376be9cd97a7ea033a3218); ?>
<?php endif; ?><?php /**PATH D:\OSPanel\domains\example-app\resources\views/brands/edit.blade.php ENDPATH**/ ?>