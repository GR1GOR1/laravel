<div class="mb-3">
    <?php if (isset($component)) { $__componentOriginalcebf39fa723eb9b9c28459b67e5de0c3 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalcebf39fa723eb9b9c28459b67e5de0c3 = $attributes; } ?>
<?php $component = ProtoneMedia\LaravelFormComponents\Components\FormInput::resolve(['name' => 'title','label' => 'Марка авто'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('form-input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(ProtoneMedia\LaravelFormComponents\Components\FormInput::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalcebf39fa723eb9b9c28459b67e5de0c3)): ?>
<?php $attributes = $__attributesOriginalcebf39fa723eb9b9c28459b67e5de0c3; ?>
<?php unset($__attributesOriginalcebf39fa723eb9b9c28459b67e5de0c3); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalcebf39fa723eb9b9c28459b67e5de0c3)): ?>
<?php $component = $__componentOriginalcebf39fa723eb9b9c28459b67e5de0c3; ?>
<?php unset($__componentOriginalcebf39fa723eb9b9c28459b67e5de0c3); ?>
<?php endif; ?>
</div><?php /**PATH D:\OSPanel\domains\example-app\resources\views/brands/form.blade.php ENDPATH**/ ?>