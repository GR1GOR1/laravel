<?php if (isset($component)) { $__componentOriginalf033baadcf10cc1e2c90a9d7fc105a54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalf033baadcf10cc1e2c90a9d7fc105a54 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layout.guest','data' => ['title' => 'Car #'.e($car->id).'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('layout.guest'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Car #'.e($car->id).'']); ?>
<a href="<?php echo e(route('home')); ?>" >Машинки</a>
<hr>
    <div><span class="fs-2">Модель:</span> <?php echo e($car->model); ?></div>
    <div><span class="fs-2">Брэнд:</span> <?php echo e($car->brand->title); ?></div>
    <div><span class="fs-2">Трансмиссия:</span> <?php echo e($car->transmission); ?></div>
    <div><?php echo e($car->created_at); ?></div>
    <div><span class="fs-2">ВИН:</span> <?php echo e($car->vin); ?></div>
    <?php if (isset($component)) { $__componentOriginaldeec63f9a1187b568067fa4933e177f0 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginaldeec63f9a1187b568067fa4933e177f0 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.comments.create','data' => ['id' => $car->id,'model' => 'car']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('comments.create'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['id' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($car->id),'model' => 'car']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginaldeec63f9a1187b568067fa4933e177f0)): ?>
<?php $attributes = $__attributesOriginaldeec63f9a1187b568067fa4933e177f0; ?>
<?php unset($__attributesOriginaldeec63f9a1187b568067fa4933e177f0); ?>
<?php endif; ?>
<?php if (isset($__componentOriginaldeec63f9a1187b568067fa4933e177f0)): ?>
<?php $component = $__componentOriginaldeec63f9a1187b568067fa4933e177f0; ?>
<?php unset($__componentOriginaldeec63f9a1187b568067fa4933e177f0); ?>
<?php endif; ?>
    <?php if (isset($component)) { $__componentOriginalc925664c115607118363b29d32706c93 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalc925664c115607118363b29d32706c93 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.comments.viewer','data' => ['model' => $car]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('comments.viewer'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['model' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($car)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalc925664c115607118363b29d32706c93)): ?>
<?php $attributes = $__attributesOriginalc925664c115607118363b29d32706c93; ?>
<?php unset($__attributesOriginalc925664c115607118363b29d32706c93); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc925664c115607118363b29d32706c93)): ?>
<?php $component = $__componentOriginalc925664c115607118363b29d32706c93; ?>
<?php unset($__componentOriginalc925664c115607118363b29d32706c93); ?>
<?php endif; ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalf033baadcf10cc1e2c90a9d7fc105a54)): ?>
<?php $attributes = $__attributesOriginalf033baadcf10cc1e2c90a9d7fc105a54; ?>
<?php unset($__attributesOriginalf033baadcf10cc1e2c90a9d7fc105a54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf033baadcf10cc1e2c90a9d7fc105a54)): ?>
<?php $component = $__componentOriginalf033baadcf10cc1e2c90a9d7fc105a54; ?>
<?php unset($__componentOriginalf033baadcf10cc1e2c90a9d7fc105a54); ?>
<?php endif; ?><?php /**PATH D:\OSPanel\domains\example-app\resources\views/public/cars/show.blade.php ENDPATH**/ ?>