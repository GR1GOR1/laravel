<div class="<?php if($type === 'hidden'): ?> hidden <?php else: ?> mt-4 <?php endif; ?>">
    <label class="block">
        <?php if (isset($component)) { $__componentOriginalfbbe8b6ca40abf152d2eb23603f97612 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalfbbe8b6ca40abf152d2eb23603f97612 = $attributes; } ?>
<?php $component = ProtoneMedia\LaravelFormComponents\Components\FormLabel::resolve(['label' => $label] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('form-label'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(ProtoneMedia\LaravelFormComponents\Components\FormLabel::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalfbbe8b6ca40abf152d2eb23603f97612)): ?>
<?php $attributes = $__attributesOriginalfbbe8b6ca40abf152d2eb23603f97612; ?>
<?php unset($__attributesOriginalfbbe8b6ca40abf152d2eb23603f97612); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalfbbe8b6ca40abf152d2eb23603f97612)): ?>
<?php $component = $__componentOriginalfbbe8b6ca40abf152d2eb23603f97612; ?>
<?php unset($__componentOriginalfbbe8b6ca40abf152d2eb23603f97612); ?>
<?php endif; ?>

        <input <?php echo $attributes->merge([
            'class' => 'form-input block w-full ' . ($label ? 'mt-1' : '')
        ]); ?>

            <?php if($isWired()): ?>
                wire:model<?php echo $wireModifier(); ?>="<?php echo e($name); ?>"
            <?php else: ?>
                value="<?php echo e($value); ?>"
            <?php endif; ?>

            name="<?php echo e($name); ?>"
            type="<?php echo e($type); ?>" />
    </label>

    <?php if($hasErrorAndShow($name)): ?>
        <?php if (isset($component)) { $__componentOriginal05e9bdd21fe5d6ded727203914658ba5 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal05e9bdd21fe5d6ded727203914658ba5 = $attributes; } ?>
<?php $component = ProtoneMedia\LaravelFormComponents\Components\FormErrors::resolve(['name' => $name] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('form-errors'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(ProtoneMedia\LaravelFormComponents\Components\FormErrors::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal05e9bdd21fe5d6ded727203914658ba5)): ?>
<?php $attributes = $__attributesOriginal05e9bdd21fe5d6ded727203914658ba5; ?>
<?php unset($__attributesOriginal05e9bdd21fe5d6ded727203914658ba5); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal05e9bdd21fe5d6ded727203914658ba5)): ?>
<?php $component = $__componentOriginal05e9bdd21fe5d6ded727203914658ba5; ?>
<?php unset($__componentOriginal05e9bdd21fe5d6ded727203914658ba5); ?>
<?php endif; ?>
    <?php endif; ?>
</div><?php /**PATH D:\OSPanel\domains\example-app\vendor\protonemedia\laravel-form-components\src\Support/../../resources/views/tailwind/form-input.blade.php ENDPATH**/ ?>