<div class="mb-3">
    <?php if (isset($component)) { $__componentOriginaldcd3f85e3f1bd18db9424edd6b6629d5 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginaldcd3f85e3f1bd18db9424edd6b6629d5 = $attributes; } ?>
<?php $component = ProtoneMedia\LaravelFormComponents\Components\FormSelect::resolve(['name' => 'brand_id','label' => 'Марка авто','placeholder' => 'Не выбрано','options' => $brands] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('form-select'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(ProtoneMedia\LaravelFormComponents\Components\FormSelect::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginaldcd3f85e3f1bd18db9424edd6b6629d5)): ?>
<?php $attributes = $__attributesOriginaldcd3f85e3f1bd18db9424edd6b6629d5; ?>
<?php unset($__attributesOriginaldcd3f85e3f1bd18db9424edd6b6629d5); ?>
<?php endif; ?>
<?php if (isset($__componentOriginaldcd3f85e3f1bd18db9424edd6b6629d5)): ?>
<?php $component = $__componentOriginaldcd3f85e3f1bd18db9424edd6b6629d5; ?>
<?php unset($__componentOriginaldcd3f85e3f1bd18db9424edd6b6629d5); ?>
<?php endif; ?>
</div>
<div class="mb-3">
    <?php if (isset($component)) { $__componentOriginalcebf39fa723eb9b9c28459b67e5de0c3 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalcebf39fa723eb9b9c28459b67e5de0c3 = $attributes; } ?>
<?php $component = ProtoneMedia\LaravelFormComponents\Components\FormInput::resolve(['name' => 'model','label' => 'Модель авто'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('form-input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(ProtoneMedia\LaravelFormComponents\Components\FormInput::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalcebf39fa723eb9b9c28459b67e5de0c3)): ?>
<?php $attributes = $__attributesOriginalcebf39fa723eb9b9c28459b67e5de0c3; ?>
<?php unset($__attributesOriginalcebf39fa723eb9b9c28459b67e5de0c3); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalcebf39fa723eb9b9c28459b67e5de0c3)): ?>
<?php $component = $__componentOriginalcebf39fa723eb9b9c28459b67e5de0c3; ?>
<?php unset($__componentOriginalcebf39fa723eb9b9c28459b67e5de0c3); ?>
<?php endif; ?>
</div>
<div class="mb-3">
    <?php if (isset($component)) { $__componentOriginalcebf39fa723eb9b9c28459b67e5de0c3 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalcebf39fa723eb9b9c28459b67e5de0c3 = $attributes; } ?>
<?php $component = ProtoneMedia\LaravelFormComponents\Components\FormInput::resolve(['name' => 'vin','label' => 'VIN'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('form-input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(ProtoneMedia\LaravelFormComponents\Components\FormInput::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalcebf39fa723eb9b9c28459b67e5de0c3)): ?>
<?php $attributes = $__attributesOriginalcebf39fa723eb9b9c28459b67e5de0c3; ?>
<?php unset($__attributesOriginalcebf39fa723eb9b9c28459b67e5de0c3); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalcebf39fa723eb9b9c28459b67e5de0c3)): ?>
<?php $component = $__componentOriginalcebf39fa723eb9b9c28459b67e5de0c3; ?>
<?php unset($__componentOriginalcebf39fa723eb9b9c28459b67e5de0c3); ?>
<?php endif; ?>
</div>
<div class="mb-3">
    <?php if (isset($component)) { $__componentOriginaldcd3f85e3f1bd18db9424edd6b6629d5 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginaldcd3f85e3f1bd18db9424edd6b6629d5 = $attributes; } ?>
<?php $component = ProtoneMedia\LaravelFormComponents\Components\FormSelect::resolve(['name' => 'transmission','label' => 'Коробка передач','placeholder' => 'Не выбрано','options' => $transmissions] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('form-select'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(ProtoneMedia\LaravelFormComponents\Components\FormSelect::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginaldcd3f85e3f1bd18db9424edd6b6629d5)): ?>
<?php $attributes = $__attributesOriginaldcd3f85e3f1bd18db9424edd6b6629d5; ?>
<?php unset($__attributesOriginaldcd3f85e3f1bd18db9424edd6b6629d5); ?>
<?php endif; ?>
<?php if (isset($__componentOriginaldcd3f85e3f1bd18db9424edd6b6629d5)): ?>
<?php $component = $__componentOriginaldcd3f85e3f1bd18db9424edd6b6629d5; ?>
<?php unset($__componentOriginaldcd3f85e3f1bd18db9424edd6b6629d5); ?>
<?php endif; ?>
</div>
<div class="mb-3">
    <?php if (isset($component)) { $__componentOriginaldcd3f85e3f1bd18db9424edd6b6629d5 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginaldcd3f85e3f1bd18db9424edd6b6629d5 = $attributes; } ?>
<?php $component = ProtoneMedia\LaravelFormComponents\Components\FormSelect::resolve(['name' => 'tags[]','label' => 'Теги','options' => $tags,'multiple' => true,'manyRelation' => true] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('form-select'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(ProtoneMedia\LaravelFormComponents\Components\FormSelect::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['size' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($tags->count())]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginaldcd3f85e3f1bd18db9424edd6b6629d5)): ?>
<?php $attributes = $__attributesOriginaldcd3f85e3f1bd18db9424edd6b6629d5; ?>
<?php unset($__attributesOriginaldcd3f85e3f1bd18db9424edd6b6629d5); ?>
<?php endif; ?>
<?php if (isset($__componentOriginaldcd3f85e3f1bd18db9424edd6b6629d5)): ?>
<?php $component = $__componentOriginaldcd3f85e3f1bd18db9424edd6b6629d5; ?>
<?php unset($__componentOriginaldcd3f85e3f1bd18db9424edd6b6629d5); ?>
<?php endif; ?>
</div>
<?php $__errorArgs = ['tags.*'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
    <div class="alert alert-danger"><?php echo e(message); ?></div>
<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><?php /**PATH D:\OSPanel\domains\example-app\resources\views/cars/form.blade.php ENDPATH**/ ?>