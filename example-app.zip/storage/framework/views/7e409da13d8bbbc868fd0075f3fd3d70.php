<?php if (isset($component)) { $__componentOriginal11b7562b3a376be9cd97a7ea033a3218 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal11b7562b3a376be9cd97a7ea033a3218 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layout.main','data' => ['title' => 'Cars catalog','h1' => 'Cars']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('layout.main'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Cars catalog','h1' => 'Cars']); ?>
    <hr>
    <a href="/cars/create">Create car</a>
    <hr>
    <div class="roe">
        <?php $__currentLoopData = $cars; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $car): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col m-3">
                <em><?php echo e($car->brand->country->title); ?> <?php echo e($car->status->text()); ?></em>
                <h3><?php echo e($car->model); ?> / <?php echo e($car->brand->title); ?> / <?php echo e($car->vin); ?></h3>
                <a href="<?php echo e(route('cars.show', [$car->id])); ?>">Подробнее</a>
                <a href="<?php echo e(route('cars.edit', [$car->id])); ?>">Редактировать</a>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal11b7562b3a376be9cd97a7ea033a3218)): ?>
<?php $attributes = $__attributesOriginal11b7562b3a376be9cd97a7ea033a3218; ?>
<?php unset($__attributesOriginal11b7562b3a376be9cd97a7ea033a3218); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal11b7562b3a376be9cd97a7ea033a3218)): ?>
<?php $component = $__componentOriginal11b7562b3a376be9cd97a7ea033a3218; ?>
<?php unset($__componentOriginal11b7562b3a376be9cd97a7ea033a3218); ?>
<?php endif; ?><?php /**PATH D:\OSPanel\domains\example-app\resources\views/cars/index.blade.php ENDPATH**/ ?>