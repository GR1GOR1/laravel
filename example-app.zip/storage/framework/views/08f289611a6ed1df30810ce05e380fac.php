<?php if (isset($component)) { $__componentOriginalf033baadcf10cc1e2c90a9d7fc105a54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalf033baadcf10cc1e2c90a9d7fc105a54 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layout.guest','data' => ['title' => 'Vhod na sait =)']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('layout.guest'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Vhod na sait =)']); ?>
    <?php if (isset($component)) { $__componentOriginal38da2dbee375aea5e7cbb453375a9e32 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal38da2dbee375aea5e7cbb453375a9e32 = $attributes; } ?>
<?php $component = ProtoneMedia\LaravelFormComponents\Components\Form::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('form'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(ProtoneMedia\LaravelFormComponents\Components\Form::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['action' => ''.e(route('auth.sessions.store')).'']); ?>
    <div class="mb-3">
        <?php if (isset($component)) { $__componentOriginalcebf39fa723eb9b9c28459b67e5de0c3 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalcebf39fa723eb9b9c28459b67e5de0c3 = $attributes; } ?>
<?php $component = ProtoneMedia\LaravelFormComponents\Components\FormInput::resolve(['name' => 'email','type' => 'email','label' => 'Email'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('form-input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(ProtoneMedia\LaravelFormComponents\Components\FormInput::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalcebf39fa723eb9b9c28459b67e5de0c3)): ?>
<?php $attributes = $__attributesOriginalcebf39fa723eb9b9c28459b67e5de0c3; ?>
<?php unset($__attributesOriginalcebf39fa723eb9b9c28459b67e5de0c3); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalcebf39fa723eb9b9c28459b67e5de0c3)): ?>
<?php $component = $__componentOriginalcebf39fa723eb9b9c28459b67e5de0c3; ?>
<?php unset($__componentOriginalcebf39fa723eb9b9c28459b67e5de0c3); ?>
<?php endif; ?>
    </div>
    <div class="mb-3">
        <?php if (isset($component)) { $__componentOriginalcebf39fa723eb9b9c28459b67e5de0c3 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalcebf39fa723eb9b9c28459b67e5de0c3 = $attributes; } ?>
<?php $component = ProtoneMedia\LaravelFormComponents\Components\FormInput::resolve(['name' => 'password','type' => 'password','label' => 'Password'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('form-input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(ProtoneMedia\LaravelFormComponents\Components\FormInput::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalcebf39fa723eb9b9c28459b67e5de0c3)): ?>
<?php $attributes = $__attributesOriginalcebf39fa723eb9b9c28459b67e5de0c3; ?>
<?php unset($__attributesOriginalcebf39fa723eb9b9c28459b67e5de0c3); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalcebf39fa723eb9b9c28459b67e5de0c3)): ?>
<?php $component = $__componentOriginalcebf39fa723eb9b9c28459b67e5de0c3; ?>
<?php unset($__componentOriginalcebf39fa723eb9b9c28459b67e5de0c3); ?>
<?php endif; ?>
    </div>
    <div class="mb-3">
        <?php if (isset($component)) { $__componentOriginale6be4f7a7db718e31412a8936028a3b9 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale6be4f7a7db718e31412a8936028a3b9 = $attributes; } ?>
<?php $component = ProtoneMedia\LaravelFormComponents\Components\FormCheckbox::resolve(['name' => 'remember','label' => 'Remember'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('form-checkbox'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(ProtoneMedia\LaravelFormComponents\Components\FormCheckbox::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale6be4f7a7db718e31412a8936028a3b9)): ?>
<?php $attributes = $__attributesOriginale6be4f7a7db718e31412a8936028a3b9; ?>
<?php unset($__attributesOriginale6be4f7a7db718e31412a8936028a3b9); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale6be4f7a7db718e31412a8936028a3b9)): ?>
<?php $component = $__componentOriginale6be4f7a7db718e31412a8936028a3b9; ?>
<?php unset($__componentOriginale6be4f7a7db718e31412a8936028a3b9); ?>
<?php endif; ?>
    </div>
        <div class="mb-3">
            <button class="btn btn-success">Войти</button>
        </div>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal38da2dbee375aea5e7cbb453375a9e32)): ?>
<?php $attributes = $__attributesOriginal38da2dbee375aea5e7cbb453375a9e32; ?>
<?php unset($__attributesOriginal38da2dbee375aea5e7cbb453375a9e32); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal38da2dbee375aea5e7cbb453375a9e32)): ?>
<?php $component = $__componentOriginal38da2dbee375aea5e7cbb453375a9e32; ?>
<?php unset($__componentOriginal38da2dbee375aea5e7cbb453375a9e32); ?>
<?php endif; ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalf033baadcf10cc1e2c90a9d7fc105a54)): ?>
<?php $attributes = $__attributesOriginalf033baadcf10cc1e2c90a9d7fc105a54; ?>
<?php unset($__attributesOriginalf033baadcf10cc1e2c90a9d7fc105a54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf033baadcf10cc1e2c90a9d7fc105a54)): ?>
<?php $component = $__componentOriginalf033baadcf10cc1e2c90a9d7fc105a54; ?>
<?php unset($__componentOriginalf033baadcf10cc1e2c90a9d7fc105a54); ?>
<?php endif; ?><?php /**PATH D:\OSPanel\domains\example-app\resources\views/auth/sessions/create.blade.php ENDPATH**/ ?>