<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag; ?>
<?php foreach($attributes->onlyProps([
    'id',
    'model'
]) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $attributes = $attributes->exceptProps([
    'id',
    'model'
]); ?>
<?php foreach (array_filter(([
    'id',
    'model'
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>

<?php if (isset($component)) { $__componentOriginal38da2dbee375aea5e7cbb453375a9e32 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal38da2dbee375aea5e7cbb453375a9e32 = $attributes; } ?>
<?php $component = ProtoneMedia\LaravelFormComponents\Components\Form::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('form'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(ProtoneMedia\LaravelFormComponents\Components\Form::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['action' => ''.e(route('comments.store')).'']); ?>
    <input type="hidden" name="id" value="<?php echo e($id); ?>">
    <input type="hidden" name="model" value="<?php echo e($model); ?>">
    <?php if (isset($component)) { $__componentOriginal0d7f5cf776e88b6d3d476b2071ad9b6a = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal0d7f5cf776e88b6d3d476b2071ad9b6a = $attributes; } ?>
<?php $component = ProtoneMedia\LaravelFormComponents\Components\FormTextarea::resolve(['name' => 'text','label' => 'Текст комментария'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('form-textarea'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(ProtoneMedia\LaravelFormComponents\Components\FormTextarea::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal0d7f5cf776e88b6d3d476b2071ad9b6a)): ?>
<?php $attributes = $__attributesOriginal0d7f5cf776e88b6d3d476b2071ad9b6a; ?>
<?php unset($__attributesOriginal0d7f5cf776e88b6d3d476b2071ad9b6a); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal0d7f5cf776e88b6d3d476b2071ad9b6a)): ?>
<?php $component = $__componentOriginal0d7f5cf776e88b6d3d476b2071ad9b6a; ?>
<?php unset($__componentOriginal0d7f5cf776e88b6d3d476b2071ad9b6a); ?>
<?php endif; ?>
    <div class="mb-3 mt-3">
        <button class="btn btn-success">Сохранить</button>
     </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal38da2dbee375aea5e7cbb453375a9e32)): ?>
<?php $attributes = $__attributesOriginal38da2dbee375aea5e7cbb453375a9e32; ?>
<?php unset($__attributesOriginal38da2dbee375aea5e7cbb453375a9e32); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal38da2dbee375aea5e7cbb453375a9e32)): ?>
<?php $component = $__componentOriginal38da2dbee375aea5e7cbb453375a9e32; ?>
<?php unset($__componentOriginal38da2dbee375aea5e7cbb453375a9e32); ?>
<?php endif; ?><?php /**PATH D:\OSPanel\domains\example-app\resources\views/components/comments/create.blade.php ENDPATH**/ ?>