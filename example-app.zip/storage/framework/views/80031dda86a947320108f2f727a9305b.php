<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag; ?>
<?php foreach($attributes->onlyProps([
    'title',
    'h1' => null
]) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $attributes = $attributes->exceptProps([
    'title',
    'h1' => null
]); ?>
<?php foreach (array_filter(([
    'title',
    'h1' => null
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo e($title); ?></title>
    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.scss']); ?>
</head>
<body>
    <header>
        <div class="container border-bottom pt-2 pb-2 mb-2">
           <div class="row">
                <div class="col"><div class="alert">Logo</div></div>
                <div class="col d-flex justify-content-end">
                    <?php if(auth()->guard()->check()): ?>
                        U`r cool bro!
                    <?php else: ?>
                        <a href="<?php echo e(route('auth.sessions.create')); ?>">Login</a>
                    <?php endif; ?>
                </div>
           </div>
            <a href="/posts">POSTS</a>
            <a href="/cars">CARS</a>
        </div>
    </header>
    <!-- Лучше сделать отдельным компонентом -->
    <!-- Можно сразу подготовить конфиг гед будут текст и тип сообщения, т.е. не писать отдельно успешный алерт -->
    <div class="container">
    <div class="row">
        <div class="col col-3">Menu</div>
        <div class="col col-9">
            <div class="container">
                <h1><?php echo e($h1 ?? $title); ?></h1>
                <?php echo e($slot); ?>

            </div>
        </div>
    </div>
    </div>
    <footer>
        <div class="container border-bottom pt-2">
            Footer
        </div>
    </footer>
    <script>
        window.appData = <?php echo e(Js::from([ 'apiRoot' => '/api' ])); ?>;
    </script>
    <?php echo app('Illuminate\Foundation\Vite')(['resources/js/app.js']); ?>
</body>
</html><?php /**PATH D:\OSPanel\domains\example-app\resources\views/components/layout/guest.blade.php ENDPATH**/ ?>