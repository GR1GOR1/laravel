<?php

use App\Models\Car;
use App\Models\Brand;

return [
    'car' => Car::class,
    'brand' => Brand::class
];