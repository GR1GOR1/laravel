<?

return [
    'framework' => 'bootstrap-5',
];