<?

return [
    'transmissions' => [
        0 => 'Автомат',
        1 => 'Механика',
        2 => 'Робот'
    ],
    'other' => [
        0 => 'var 1',
        1 => 'var 2'
    ]
];