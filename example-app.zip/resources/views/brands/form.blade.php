<div class="mb-3">
    <x-form-input name="title" label="Марка авто"/>
</div>